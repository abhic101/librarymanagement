# Installing dependencies
Open this directory in terminal and run `npm install` to install all the dependencies.

## Run development server 
Use command `node index.js` to start development server at `http://localhost:3000/`.

