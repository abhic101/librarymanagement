export interface Student {
    _id:string,
    name:string,
    pageno:Number,
    author:string,
    category:string,
    rollno:Number,
    fromdate:string,
    todate:string,
    thumbnail:string,
}
