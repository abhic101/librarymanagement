export interface Totalbooks {
    _id:string,
    name:string,
    author:string,
    category:string,
    publication:string,
    pageno:string,
    price:string,
    avilablenumber:number,
    thumbnail:string
}