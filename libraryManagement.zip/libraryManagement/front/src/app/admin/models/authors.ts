export interface Authors {
    _id:string,
    author:string
}
