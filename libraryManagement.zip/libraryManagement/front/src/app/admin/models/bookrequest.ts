export interface BookRequest {
    _id:string,
    name:string,
    author:string,
    category:string,
    publication:string
}
