export interface CategoryBooks {
    _id:string,
    category:string
}
