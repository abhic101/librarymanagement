export interface Registerstudent {
    _id:string,
    firstname:string,
    secondname:string,
    email:string,
    dateofbirth:string,
    gender:string,
    department:string,
    year:string,
    rollno:string,
    password:string
}
