import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-addbooks',
  templateUrl: './addbooks.component.html',
  styleUrls: ['./addbooks.component.css']
})
export class AddbooksComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
 
  }
}
