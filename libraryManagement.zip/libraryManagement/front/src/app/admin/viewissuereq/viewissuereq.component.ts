import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewissuereq',
  templateUrl: './viewissuereq.component.html',
  styleUrls: ['./viewissuereq.component.css']
})
export class ViewissuereqComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
